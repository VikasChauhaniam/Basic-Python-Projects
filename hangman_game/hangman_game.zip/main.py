import random
import hangman_art
import hangman_words

print_list = list()
lives = 6

print(hangman_art.logo)
word_list =hangman_words.word_lists
stages=hangman_art.stage

actual_word = random.choice(word_list)
print(f" SOLUTION IS: {actual_word}\n")

for _ in range(len(actual_word)):
  print_list += "_"
print(print_list)  

found = False
while "_" in print_list:
  guess = input("\nGuess a letter: ").lower()
  print("=======================")
  found = False
  for indx in range(len(actual_word)):
    if guess==actual_word[indx]:
      print_list[indx] = guess
      found = True
    if "_" not in print_list:
      print("--------------------YOU-WIN-------------------")
      exit(1)
    else:
      if found == False and indx == len(actual_word)-1 :
        lives = lives -1
        print("wrong letter")
        print(stages[lives])

        if lives==0:
          print("---You Loose---")
          print("---------------Game-Over------------------") 
          exit()
        
  
  print(print_list)
  
  if "_" not in print_list:
    print("PASS")
  





     

    



